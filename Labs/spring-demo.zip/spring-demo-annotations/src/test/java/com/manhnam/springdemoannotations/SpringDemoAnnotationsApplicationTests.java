package com.manhnam.springdemoannotations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDemoAnnotationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
